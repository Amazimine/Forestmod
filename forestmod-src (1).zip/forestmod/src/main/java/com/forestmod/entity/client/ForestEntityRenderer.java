package com.forestmod.entity.client;

import com.forestmod.ForestMod;
import com.forestmod.entity.ForestEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class ForestEntityRenderer extends MobEntityRenderer<ForestEntity, ForestModel> {

    private static final Identifier TEXTURE =
            Identifier.of(ForestMod.MOD_ID, "textures/entity/forest_entity.png");

    public ForestEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new ForestModel(context.getPart(ForestModel.LAYER_LOCATION)), 0.5f);
    }

    @Override
    public Identifier getTexture(ForestEntity entity) {
        return TEXTURE;
    }
}
