package com.forestmod.entity;

import com.forestmod.ForestMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {

    public static final EntityType<ForestEntity> FOREST_ENTITY =
            Registry.register(
                    Registries.ENTITY_TYPE,
                    Identifier.of(ForestMod.MOD_ID, "forest_entity"),
                    FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, ForestEntity::new)
                            .dimensions(EntityDimensions.fixed(1.0f, 2.5f))
                            .build()
            );

    public static void register() {
        // Invoked so the static fields are initialised
    }
}
