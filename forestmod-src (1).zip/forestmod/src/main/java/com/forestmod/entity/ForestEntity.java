package com.forestmod.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.world.World;

public class ForestEntity extends HostileEntity {

    public ForestEntity(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.22)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 4.0);
    }

    @Override
    protected void initGoals() {
        // Priority 1 — don't drown / fall off cliffs
        this.goalSelector.add(1, new SwimGoal(this));

        // Priority 2 — wander slowly around the world
        this.goalSelector.add(2, new WanderAroundFarGoal(this, 0.8, 0.003F));

        // Priority 3 — look at the nearest player
        this.goalSelector.add(3, new LookAtEntityGoal(this,
                net.minecraft.entity.player.PlayerEntity.class, 16.0f));

        // Priority 4 — look around randomly when idle
        this.goalSelector.add(4, new LookAroundGoal(this));
    }

    // Passive for now — no target goals, no attack goals
    // (horror AI will be added in a future version)
}
