package com.forestmod.entity.client;

import com.forestmod.ForestMod;
import com.forestmod.entity.ForestEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class ForestModel extends EntityModel<ForestEntity> {

    public static final EntityModelLayer LAYER_LOCATION =
            new EntityModelLayer(Identifier.of(ForestMod.MOD_ID, "forest_entity"), "main");

    private final ModelPart bone;
    private final ModelPart bone2;
    private final ModelPart bb_main;

    public ForestModel(ModelPart root) {
        this.bone    = root.getChild("bone");
        this.bone2   = root.getChild("bone2");
        this.bb_main = root.getChild("bb_main");
    }

    public static TexturedModelData createBodyLayer() {
        ModelData modelData = new ModelData();
        ModelPartData partData = modelData.getRoot();

        // ── bone (left tendril cluster) ─────────────────────────────────────
        ModelPartData bone = partData.addChild("bone",
                ModelPartBuilder.create()
                        .uv(16, 36).cuboid(0, -30,  2.5f, 2, 2, 2)
                        .uv(16, 40).cuboid(0, -31,  4.5f, 2, 2, 2)
                        .uv(40, 16).cuboid(0, -32,  5.5f, 2, 2, 2)
                        .uv(40, 24).cuboid(0, -35,  5.5f, 2, 2, 2)
                        .uv(40, 28).cuboid(0, -36,  4.5f, 2, 2, 2)
                        .uv(40, 32).cuboid(0, -37,  5.5f, 2, 2, 2)
                        .uv(40, 32).cuboid(0, -34,  5.5f, 2, 2, 2)
                        .uv(40, 36).cuboid(0, -33,  7.5f, 2, 2, 2)
                        .uv(40, 40).cuboid(0, -34,  8.5f, 2, 2, 2)
                        .uv(16, 44).cuboid(0, -35,  9.5f, 2, 2, 2)
                        .uv(40, 44).cuboid(0, -36, 10.5f, 2, 2, 2)
                        .uv(48,  0).cuboid(0, -38, 11.5f, 2, 2, 2)
                        .uv(48,  4).cuboid(0, -39, 12.5f, 2, 2, 2)
                        .uv(48,  8).cuboid(0, -40, 12.5f, 2, 2, 2)
                        .uv(16, 48).cuboid(0, -37,  9.5f, 2, 2, 2)
                        .uv(48, 16).cuboid(0, -39,  8.5f, 2, 2, 2)
                        .uv(48, 20).cuboid(0, -40,  7.5f, 2, 2, 2)
                        .uv(24, 48).cuboid(0, -41,  6.5f, 2, 2, 2),
                ModelTransform.pivot(0, 24, 3));

        // ── bone2 (right / rear tendril cluster) ────────────────────────────
        ModelPartData bone2 = partData.addChild("bone2",
                ModelPartBuilder.create()
                        .uv(48, 28).cuboid(0,  -1, -0.5f, 2, 2, 2)
                        .uv(32, 48).cuboid(0,  -2,  1.5f, 2, 2, 2)
                        .uv(48, 32).cuboid(0,  -3,  2.5f, 2, 2, 2)
                        .uv(48, 36).cuboid(0,  -4,  2.5f, 2, 2, 2)
                        .uv(40, 48).cuboid(0,  -6,  2.5f, 2, 2, 2)
                        .uv(48, 40).cuboid(0,  -7,  1.5f, 2, 2, 2)
                        .uv(48, 44).cuboid(0,  -8,  2.5f, 2, 2, 2)
                        .uv(48, 48).cuboid(0,  -4,  4.5f, 2, 2, 2)
                        .uv(48, 24).cuboid(0,  -5,  5.5f, 2, 2, 2)
                        .uv( 8, 52).cuboid(0,  -7,  7.5f, 2, 2, 2)
                        .uv(16, 52).cuboid(0,  -9,  8.5f, 2, 2, 2)
                        .uv(24, 52).cuboid(0, -10,  9.5f, 2, 2, 2)
                        .uv(32, 52).cuboid(0, -11,  9.5f, 2, 2, 2)
                        .uv(40, 52).cuboid(0,  -6,  6.5f, 2, 2, 2)
                        .uv(48, 52).cuboid(0,  -8,  6.5f, 2, 2, 2)
                        .uv( 0, 56).cuboid(0, -10,  5.5f, 2, 2, 2)
                        .uv(56,  0).cuboid(0, -11,  4.5f, 2, 2, 2)
                        .uv(56,  4).cuboid(0, -12,  3.5f, 2, 2, 2),
                ModelTransform.of(2, -6, -1, 0, (float) Math.PI, 0));

        // ── bb_main (body + head column) ─────────────────────────────────────
        ModelPartData bb_main = partData.addChild("bb_main",
                ModelPartBuilder.create()
                        .uv(24, 16).cuboid(-1, -12, -3,  4, 12, 4)
                        .uv(32,  0).cuboid(-1, -12,  1,  4, 12, 4)
                        .uv( 0, 16).cuboid(-1, -24, -4,  4, 12, 8)
                        .uv(24, 32).cuboid(-1, -24,  4,  4, 12, 4)
                        .uv( 0, 36).cuboid(-1, -25, -8,  4, 12, 4)
                        .uv( 0,  0).cuboid(-3, -32, -2,  8,  8, 8)
                        // root protrusions
                        .uv( 8, 56).cuboid( 2, -25,  2,  2, 2, 2)
                        .uv(56,  8).cuboid( 2, -16, -2,  2, 2, 2)
                        .uv(56, 12).cuboid( 2, -16,  7,  2, 2, 2)
                        .uv(16, 56).cuboid( 2, -22, -7,  2, 2, 2)
                        .uv(56, 32).cuboid( 2,  -8, -2.9f, 2, 2, 2)
                        .uv(56, 36).cuboid( 2,  -5,  2.1f, 2, 2, 2)
                        .uv(40, 56).cuboid( 0, -11,  4.1f, 2, 2, 2)
                        .uv(56, 40).cuboid(-2,  -3,  3.1f, 2, 2, 2)
                        .uv(56, 44).cuboid(-2,  -7, -0.9f, 2, 2, 2)
                        .uv(48, 56).cuboid(-2,  -5, -3.9f, 2, 2, 2)
                        .uv(56, 48).cuboid( 2, -13, -3.9f, 2, 2, 2)
                        .uv(56, 16).cuboid(-2, -17, -8.9f, 2, 2, 2)
                        .uv(56, 20).cuboid(-2, -17, -2.9f, 2, 2, 2)
                        .uv(24, 56).cuboid(-2, -22, -6.9f, 2, 2, 2)
                        .uv(56, 24).cuboid(-2, -15,  2.1f, 2, 2, 2)
                        .uv(56, 28).cuboid(-2, -20,  5.1f, 2, 2, 2)
                        .uv(32, 56).cuboid(-2, -25,  0.1f, 2, 2, 2),
                ModelTransform.pivot(0, 24, 0));

        return TexturedModelData.of(modelData, 64, 64);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ANIMATION
    // ─────────────────────────────────────────────────────────────────────────

    private static final float IDLE_SPEED        = 0.03f;
    private static final float IDLE_BODY_SWAY    = 0.07f;
    private static final float IDLE_BODY_BOB     = 0.4f;
    private static final float IDLE_TENDRIL_SWAY = 0.12f;
    private static final float WALK_BODY_LEAN    = 0.15f;
    private static final float WALK_BODY_BOB     = 0.6f;
    private static final float WALK_TENDRIL_SWING = 0.25f;

    @Override
    public void setAngles(ForestEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {

        float idleTime  = animationProgress * IDLE_SPEED;
        float walkSpeed = limbAngle * 0.6662f;

        float moveBlend = Math.min(limbDistance, 1.0f);
        float idleBlend = 1.0f - moveBlend;

        // ── bb_main ──────────────────────────────────────────────────────────
        bb_main.yaw   = headYaw   * ((float) Math.PI / 180f) * 0.25f;
        bb_main.pitch = headPitch * ((float) Math.PI / 180f) * 0.15f;

        float idleSway = MathHelper.sin(idleTime) * IDLE_BODY_SWAY * idleBlend;
        bb_main.roll = idleSway;

        float idleBob = MathHelper.sin(idleTime * 2.0f) * IDLE_BODY_BOB * idleBlend;
        bb_main.pivotY = 24.0f + idleBob;

        bb_main.pitch += moveBlend * WALK_BODY_LEAN;
        bb_main.pivotY += MathHelper.sin(walkSpeed * 2.0f) * WALK_BODY_BOB * moveBlend;

        // ── bone ─────────────────────────────────────────────────────────────
        float tendrilIdle  = -MathHelper.sin(idleTime + 1.0f) * IDLE_TENDRIL_SWAY;
        float tendrilWalk  =  MathHelper.sin(walkSpeed)       * WALK_TENDRIL_SWING * moveBlend;

        bone.pitch = (tendrilIdle * idleBlend) + tendrilWalk;
        bone.roll  =  tendrilIdle * idleBlend  * 0.5f;
        bone.yaw   =  MathHelper.sin(idleTime * 0.7f) * 0.04f;

        // ── bone2 ────────────────────────────────────────────────────────────
        bone2.pitch = (tendrilIdle * idleBlend) - tendrilWalk;
        bone2.roll  = -tendrilIdle * idleBlend  * 0.5f;
        bone2.yaw   = -MathHelper.sin(idleTime * 0.7f + 0.5f) * 0.04f;
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices,
                       int light, int overlay, int color) {
        bone.render(matrices,   vertices, light, overlay, color);
        bone2.render(matrices,  vertices, light, overlay, color);
        bb_main.render(matrices, vertices, light, overlay, color);
    }
}
