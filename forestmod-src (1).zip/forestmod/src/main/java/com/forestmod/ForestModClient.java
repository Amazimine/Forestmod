package com.forestmod;

import com.forestmod.entity.ModEntities;
import com.forestmod.entity.client.ForestEntityRenderer;
import com.forestmod.entity.client.ForestModel;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class ForestModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.FOREST_ENTITY, ForestEntityRenderer::new);
        EntityModelLayerRegistry.registerModelLayer(ForestModel.LAYER_LOCATION, ForestModel::createBodyLayer);
    }
}
